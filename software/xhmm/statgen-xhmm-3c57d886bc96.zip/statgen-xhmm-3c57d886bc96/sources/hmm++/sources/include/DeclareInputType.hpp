#ifndef __DECLARE_INPUT_TYPE_H__
#define __DECLARE_INPUT_TYPE_H__

namespace HMM_PP {

	template<class Type>
	class DeclareInputType {

	public:
		typedef Type InputType;
	};
}

#endif
